package com.codingplatform.repository;

import com.codingplatform.model.Discussion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DiscussionRepository extends JpaRepository<Discussion, Long> {
    List<Discussion> findByProblemIdOrderByCreatedAtDesc(Long problemId);
}
